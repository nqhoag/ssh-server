<html>
    <head>
        <title>Manage SSH Server</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
        <div id="menu">
            <ul>
                <li><a href="/ssh/" title="Home">Trang chính</a></li>
                <li><a href="/ssh/?mod=up" title="Up new ssh">Up ssh</a></li>
                <li><a href="/ssh/?mod=up2" title="Up new ssh">Up ssh 2</a></li>
                <li><a href="/ssh/?mod=get" title="Get ssh">Get ssh</a></li>
                <li><a href="/ssh/?mod=clear" title="Clear all ssh">Clear ssh</a></li>
                <li><a href="/ssh/logout.php" title="Log out">Log out</a></li>
            </ul>
        </div>
        <div id="main">